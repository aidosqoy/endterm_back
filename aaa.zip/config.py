# import os
#
# from flask import current_app
#
#
# class Config:
#     SECRET_KEY = 'secret_key'
#     SQLALCHEMY_DATABASE_URI = 'sqlite:///site.db'
#     SQLALCHEMY_TRACK_MODIFICATIONS = False
#     UPLOAD_FOLDER = os.path.join(current_app.root_path, 'app', 'static', 'uploads')
